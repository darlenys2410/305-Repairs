# 📱 Cómo publicar en GitHub Pages

## Paso 1: Crear un repositorio en GitHub

1. Ve a https://github.com/new
2. Nombre del repositorio: `305-reparaciones`
3. Descripción: "App para registrar reparaciones de equipos"
4. Selecciona "Public" (públic)
5. Haz clic en "Create repository"

## Paso 2: Cargar los archivos

Tienes dos opciones:

### Opción A: Por la web (más fácil)

1. En la página del repositorio, haz clic en "Add file" → "Upload files"
2. Arrastra o selecciona estos 4 archivos:
   - `index.html`
   - `en.html`
   - `manifest.json`
   - `README.md`
3. Haz clic en "Commit changes"

### Opción B: Con Git (si tienes Git instalado)

```bash
cd ruta-a-la-carpeta-305-reparaciones
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/305-reparaciones.git
git push -u origin main
```

## Paso 3: Activar GitHub Pages

1. Ve a Settings (Configuración) del repositorio
2. En el menú izquierdo, haz clic en "Pages"
3. En "Source", selecciona "main" y "/root"
4. Haz clic en "Save"

¡Espera 2-3 minutos!

## Paso 4: Acceder a tu app

Tu URL será: `https://tuusuario.github.io/305-reparaciones/`

## ✅ En iPhone

1. Abre la URL en Safari
2. Toca ⬆️
3. Toca "Agregar a pantalla de inicio"
4. ¡Listo! 🎉

---

**Nota:** Reemplaza `tuusuario` con tu nombre de usuario de GitHub.
